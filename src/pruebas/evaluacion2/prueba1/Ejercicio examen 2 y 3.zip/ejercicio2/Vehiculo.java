package pruebas.evaluacion2.prueba1.ejercicio2;

public abstract class Vehiculo {

	protected String matricula;
	protected String modelo;
	
	protected abstract void setMatricula(String matricula);
	
}
